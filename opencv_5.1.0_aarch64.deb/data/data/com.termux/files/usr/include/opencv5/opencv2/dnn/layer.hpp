/*M///////////////////////////////////////////////////////////////////////////////////////
//
//  IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING.
//
//  By downloading, copying, installing or using the software you agree to this license.
//  If you do not agree to this license, do not download, install,
//  copy or use the software.
//
//
//                           License Agreement
//                For Open Source Computer Vision Library
//
// Copyright (C) 2013, OpenCV Foundation, all rights reserved.
// Third party copyrights are property of their respective owners.
//
// Redistribution and use in source and binary forms, with or without modification,
// are permitted provided that the following conditions are met:
//
//   * Redistribution's of source code must retain the above copyright notice,
//     this list of conditions and the following disclaimer.
//
//   * Redistribution's in binary form must reproduce the above copyright notice,
//     this list of conditions and the following disclaimer in the documentation
//     and/or other materials provided with the distribution.
//
//   * The name of the copyright holders may not be used to endorse or promote products
//     derived from this software without specific prior written permission.
//
// This software is provided by the copyright holders and contributors "as is" and
// any express or implied warranties, including, but not limited to, the implied
// warranties of merchantability and fitness for a particular purpose are disclaimed.
// In no event shall the Intel Corporation or contributors be liable for any direct,
// indirect, incidental, special, exemplary, or consequential damages
// (including, but not limited to, procurement of substitute goods or services;
// loss of use, data, or profits; or business interruption) however caused
// and on any theory of liability, whether in contract, strict liability,
// or tort (including negligence or otherwise) arising in any way out of
// the use of this software, even if advised of the possibility of such damage.
//
//M*/

#ifndef OPENCV_DNN_LAYER_HPP
#define OPENCV_DNN_LAYER_HPP
#include <opencv2/dnn.hpp>

namespace cv {
namespace dnn {
CV__DNN_INLINE_NS_BEGIN
//! @addtogroup dnn
//! @{
//!
//! @defgroup dnnLayerFactory Utilities for New Layers Registration
//! @{

/** @brief %Layer factory allows to create instances of registered layers. */
class CV_EXPORTS LayerFactory
{
public:

    //! Each Layer class must provide this function to the factory
    typedef Ptr<Layer>(*Constructor)(LayerParams &params);

    //! Registers the layer class with typename @p type and specified @p constructor. Thread-safe.
    static void registerLayer(const String &type, Constructor constructor);

    //! Unregisters registered layer with specified type name. Thread-safe.
    static void unregisterLayer(const String &type);

    //! Check if layer is registered.
    static bool isLayerRegistered(const std::string& type);

    /** @brief Creates instance of registered layer.
     *  @param type type name of creating layer.
     *  @param params parameters which will be used for layer initialization.
     *  @note Thread-safe.
     */
    static Ptr<Layer> createLayerInstance(const String &type, LayerParams& params);


    // Builds the abstract (metadata) node for an operation type.
    typedef Ptr<LayerInfo>(*OpConstructor)(const LayerParams& params);
    //! Builds a backend-specific executor from an LayerInfo; returns null Ptr if unsupported.
    typedef Ptr<Layer>(*ExecConstructor)(const Ptr<LayerInfo>& data, void* backendCtx);

    static void registerOp(const String& type, OpConstructor constructor);
    static Ptr<LayerInfo> createOp(const String& type, const LayerParams& params);

    static void registerExec(const String& type, int backendId, ExecConstructor constructor);
    static Ptr<Layer> createExec(const String& type, int backendId,
                                 const Ptr<LayerInfo>& data, void* backendCtx);

private:
    LayerFactory();
};

//! @}
//! @}
CV__DNN_INLINE_NS_END
}
}
#endif
