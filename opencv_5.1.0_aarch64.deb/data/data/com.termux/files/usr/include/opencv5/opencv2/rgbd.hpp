// This file is part of OpenCV project.
// It is subject to the license terms in the LICENSE file found in the top-level directory
// of this distribution and at http://opencv.org/license.html

// This code is also subject to the license terms in the LICENSE_KinectFusion.md file found in this module's directory

// This code is also subject to the license terms in the LICENSE_WillowGarage.md file found in this module's directory

#ifndef __OPENCV_RGBD_HPP__
#define __OPENCV_RGBD_HPP__

#include "opencv2/rgbd/dynafu.hpp"
#include "opencv2/rgbd/kinfu.hpp"
#include "opencv2/rgbd/colored_kinfu.hpp"
#include "opencv2/rgbd/large_kinfu.hpp"
#include "opencv2/rgbd/linemod.hpp"

/** @defgroup rgbd RGB-Depth Processing

@ref kinfu_icp
*/

#endif

/* End of file. */
